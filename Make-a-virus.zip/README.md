#VIRUS MAKER
this is a virus maker you can edit the flashing in css/ style.css you can change the colors in there

in index is the main part thats were it triggers it when open you can edit the text were it has !!!
you can also do the same to the popup it can be different text if you want it to be

to change the image go to media/img/smile-white.png and just put your image there remove the old one and for the image to work the name has to be: smile-white

if you want to change the audio or sound go to media/audio/idiot.mp3 and just put your audio there and remove the old one and rename the new one with:
idiot